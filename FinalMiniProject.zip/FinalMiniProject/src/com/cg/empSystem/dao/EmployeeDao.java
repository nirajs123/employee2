package com.cg.empSystem.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;



public interface EmployeeDao {
	int addEmployeeDetails(Employee emp) throws EmployeeException;
	boolean RemoveEmployeeDetails(int empid) throws EmployeeException, SQLException;
	List<Employee> showAll() throws EmployeeException, SQLException;
	int	isValid(String userName,String userPassword)throws EmployeeException;
	List<Employee> searchEmployee(String data)throws EmployeeException;
	
}
