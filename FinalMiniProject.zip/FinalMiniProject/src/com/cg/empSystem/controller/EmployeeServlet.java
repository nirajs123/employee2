package com.cg.empSystem.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;
import com.cg.empSystem.service.EmployeeService;
import com.cg.empSystem.service.EmployeeServiceImpl;
import com.sun.net.httpserver.HttpServer;

@WebServlet("*.do")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeService empservice = null;
	private Employee emp = null;

	public EmployeeServlet() throws EmployeeException {
		empservice = new EmployeeServiceImpl();
		emp = new Employee();
	}

	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (EmployeeException | SQLException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (EmployeeException | SQLException e) {
			e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException,
			EmployeeException, SQLException {
		String path = request.getServletPath();
		System.out.println(path);
		if (path.equals("/opreration.do")) {
			RequestDispatcher dispatch = request
					.getRequestDispatcher("opr.jsp");
			dispatch.forward(request, response);
		} else if (path.equals("/empadd.do")) {
			try {

				emp.setEmp_id(request.getParameter("empid"));
				emp.setEmp_fname(request.getParameter("fname"));
				emp.setEmp_lname(request.getParameter("lname"));
				String dstr1 = request.getParameter("dob");
				Date d1 = Date.valueOf(dstr1);
				emp.setDateOfBirth(d1);
				String dstr2 = request.getParameter("doj");
				Date d2 = Date.valueOf(dstr2);
				emp.setDateOfJoining(d2);
				emp.setEmp_deptId(Integer.parseInt(request
						.getParameter("deptid")));
				emp.setEmp_grade(request.getParameter("grade"));
				emp.setDesignation(request.getParameter("design"));
				emp.setEmp_contactNo(request.getParameter("contact"));
				emp.setEmp_gender(request.getParameter("gender"));
				emp.setEmp_maritalStatus(request.getParameter("marStatus"));
				emp.setEmp_homeAddress(request.getParameter("addr"));
				int st = empservice.addEmployeeDetails(emp);
				if (st == 1) {
					RequestDispatcher dispatch = request
							.getRequestDispatcher("added.jsp");
					dispatch.forward(request, response);
				} else {
					RequestDispatcher dispatch = request
							.getRequestDispatcher("erradd.jsp");
					dispatch.forward(request, response);
				}
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (EmployeeException e) {
				e.printStackTrace();
			}
		}

		// Authentication Begin
		else if (path.equals("/authenticate.do")) {
			System.out.println("inside admin login controller");
			String userName = request.getParameter("userName");
			String userPassword = request.getParameter("password");
			// System.out.println(adminName);
			// System.out.println(adminPass);
			int res = empservice.isAuthenticate(userName, userPassword);
			System.out.println(res);
			if (res == 0) {
				request.setAttribute("errormsg", "oopss wrong password!!!!!! ");
				RequestDispatcher dispatch = request
						.getRequestDispatcher("login.jsp");
				dispatch.forward(request, response);

			}
			if (res == 1) {

				RequestDispatcher dispatch = request
						.getRequestDispatcher("opr.jsp");
				dispatch.forward(request, response);
			}

			if (res == 2) {

				RequestDispatcher dispatch = request
						.getRequestDispatcher("employee.jsp");
				dispatch.forward(request, response);
			}

			if (res == 3) {

				request.setAttribute("errormsg", "oopss wrong username!!!!!! ");
				RequestDispatcher dispatch = request
						.getRequestDispatcher("login.jsp");
				dispatch.forward(request, response);

			}

		}// end of Authentication

		else if (path.equals("/remove.do")) {
			String enostr = request.getParameter("eno");
			int eno = Integer.parseInt(enostr);
			boolean f = empservice.RemoveEmployeeDetails(eno);
			if (f) {
				RequestDispatcher dispatch = request
						.getRequestDispatcher("deleted.jsp");
				dispatch.forward(request, response);
			} else {
				RequestDispatcher dispatch = request
						.getRequestDispatcher("errdlt.jsp");
				dispatch.forward(request, response);
			}
		}

	}

}
