package com.cg.empSystem.service;

import java.sql.SQLException;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;

public interface EmployeeService {
	public int addEmployeeDetails(Employee emp) throws EmployeeException;
	public boolean RemoveEmployeeDetails(int empid) throws EmployeeException, SQLException;
	int isAuthenticate( String userName,String userPassword)throws EmployeeException;

}
